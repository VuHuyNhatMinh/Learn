package com.example.StartSpringProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StartSpringProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(StartSpringProjectApplication.class, args);
	}

}
